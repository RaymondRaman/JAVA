package imagefileio;

import java.io.File;
import java.io.PrintStream;
import java.util.Scanner;

/**
 * Class PGM of app ImageFileIO.
 * 
 *** STUDENTS SHOULD FINISH THIS CLASS PROPERLY TO MAKE ImageFileIO WORK!
 *** All methods in class PGM do NOT handle, but just declare "throws Exception".
 * 
 * CSCI1130 Java Assignment 4 ImageFileIO
 *
 * Remark: Name your class, variables, methods, etc. properly. 
 * You should write comment for your work and follow good styles.
 *
 * I declare that the assignment here submitted is original except for source
 * material explicitly acknowledged, and that the same or closely related
 * material has not been previously submitted for another course. I also
 * acknowledge that I am aware of University policy and regulations on honesty
 * in academic work, and of the disciplinary guidelines and procedures
 * applicable to breaches of such policy and regulations, as contained in the
 * website.
 *
 * University Guideline on Academic Honesty:
 *     http://www.cuhk.edu.hk/policy/academichonesty
 * Faculty of Engineering Guidelines to Academic Honesty:
 *     https://www.erg.cuhk.edu.hk/erg/AcademicHonesty
 *
 * Section     : CSCI1130 B
 * Student Name: LI KA WAI
 * Student ID  : 1155175898
 * Date        : 06/11/2022
 *
 * Reference: https://en.wikipedia.org/wiki/Netpbm#PGM_example
 * Assumption: this assignment DOES NOT handle #comment in PGM image files
 * Tool: https://kylepaulsen.com/stuff/NetpbmViewer/
 */
public class PGM {
    
    /** all field are private */
    private int width, height, maxValue;
    private String pixels;

    /**
     * Default constructor takes no parameters.
     * Initializes this new object with width 0, height 0, maxValue 255
     * and empty String "" in pixels
     */
        /*** Students' work here ***/
    public PGM(){
        width = 0;
        height = 0;
        maxValue = 255;
        pixels = "";
    }

    /**
     * Constructor that "clones" an existing PGM object
     * Copies ALL fields from given img to this new object using assignment statements.
     * @param img is an existing PGM object
     */
        /*** Students' work here ***/
    public PGM(PGM img){
        width = img.width;
        height = img.height;
        maxValue = img.maxValue;
        pixels = img.pixels;
    }

    /**
     * Read from a PGM File using Scanner.
     * 1. Create a new File object and then a new Scanner object
     * 2. Read first token using Scanner object's next() method to get header
     * 3. If header is not equal to "P2", throw new Exception("Invalid header");
     * 4. Read following three integers as width, height and maxValue
     * 5. Read many pixel value lines AND concatenate all lines (plus newlines) as one single pixels String
     * 6. Close the Scanner object
     * @param filename is an existing ASCII file containing an image in PGM format
     * @throws Exception 
     */
    public void read(String filename) throws Exception
    {
        /*** Students' work here ***/
        File pgmFile = new File(filename);
        Scanner value = new  Scanner(pgmFile);
        
        String header = value.next();
        if(!header.equals("P2")){
            throw new Exception("Invalid header");
        }
        
        width = value.nextInt();
        height = value.nextInt();
        maxValue = value.nextInt();
        
        value.useDelimiter("    ");
        while(value.hasNext()){
            pixels += value.next();
        }
        System.out.println("Read " + filename + " with header " + header + " of image size " + width + "x" + height);
        value.close();
    }

    /**
     * Write to a PGM file using PrintStream.
     * 1. Declare and initialize a String header with content "P2"
     * 2. Create a PrintStream object with given filename
     * 3. Write header, width, height, maxValue through the PrintStream object
     * 4. Write the pixels (a String with many lines of pixel values)
     * 5. Close the PrintStream object
     * @param filename is a file to be created/ overwritten in working folder
     * @throws Exception 
     */
    public void write(String filename) throws Exception
    {
        /*** Students' work here ***/
        String header = "P2";
        PrintStream pgmFile;
        pgmFile = new PrintStream(filename);
        
        pgmFile.println(header);
        pgmFile.print(width);
        pgmFile.println("   "+ height);
        pgmFile.println(maxValue);
        
        pgmFile.print(pixels);
        System.out.println("Wrote " + filename + " with header " + header + " of image size " + width + "x" + height);
        pgmFile.close();
    }
    
    /**
     * getWidth() method
     * @return width is an int
     */
        /*** Students' work here ***/
    public int getWidth(){
        return width;
    }
    
    /**
     * getHeight() method
     * @return height is an int
     */
        /*** Students' work here ***/
    public int getHeight(){
        return height;
    }
    
    /**
     * getPixels() method
     * @return pixels String that is immutable
     */
    public String getPixels()
    {
        return pixels;
    }

    /**
     * setPixels replaces content in this PGM image with given width, height and pixels
     * @param int newWidth
     * @param int newHeight
     * @param String newPixels
     * @return type is void
     */
        /*** Students' work here ***/
    public void setPixels(int newWidth, int newHeight, String newPixels){
        width = newWidth;
        height = newHeight;
        pixels = newPixels;
    }

    /**
     * Stack this image on top of another image, keeping result in this image.
     * Both source images should have the same width; otherwise return without action.
     * Resultant image has the same width as that of both source images.
     * Height of resultant image is the sum of the height of both source images.
     * Pixels in resultant image is the concatenated result of the source pixel Strings.
     * @param img is another image that is copied and unaffected.
     */
    public void stackWith(PGM img)
    {
        /*** Students' work here ***/
        this.height += img.height;
        if(this.width == img.width){
            this.pixels += img.pixels;
        }
    }
    
    /**
     * Invert this image and return a new resultant image.
     * Refer to the technique demonstrated in given method screenShow().
     * Use maxValue to invert each and every extracted pixel value.
     * Use new StringBuilder object to rebuild a new pixels String efficiently.
     * Separate the resultant pixel values by tabs and newlines.
     * @return a new PGM that represents the inverted image of the source
     */
    
    public PGM invert()
    {
        /*** Students' work here ***/
        
        PGM invert = new PGM();
        invert.height = height;
        invert.width = width;
        
        Scanner values = new Scanner(pixels);
        for(int h = 0; h < height; h++)
        {
            for(int w = 0; w < width; w++){
                int orginalValue = values.nextInt();
                int pixelsValue1 = (maxValue - orginalValue); 
                String pixelsValue2 = Integer.toString(pixelsValue1) + "    ";
                StringBuilder str1 = new StringBuilder(pixelsValue2);
                if(w == (width - 1 ))
                    str1.append("\n");
                invert.pixels += str1.toString();
            }
        }
        
        return invert;
    }
    
    /**
     * Display this PGM as pixel values on screen for inspection and debugging.
     * Demonstrate how to use Scanner to parse pixel values in a String
     * in order to perform screen formatting.
     */
    public void screenShow()
    {
        System.out.println("Screen show of image size " + width + "x" + height + ":");
        Scanner values = new Scanner(pixels);
        for (int h = 0; h < height; h++) {
            for (int w = 0; w < width; w++)
                System.out.printf("%4d", values.nextInt());
            System.out.println();
            System.out.println();
        }
    }
}
